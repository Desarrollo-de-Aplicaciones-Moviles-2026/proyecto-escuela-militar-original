package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun EventosScreen(datos: DatosApp, usuario: UsuarioModel, detalle: (String) -> Unit, nuevo: () -> Unit = {}) {
    Pagina {
        Text(if (usuario.rol == Rol.ADMIN) "Eventos" else "Competencias", style = MaterialTheme.typography.headlineSmall)
        if (usuario.rol == Rol.ADMIN) BotonPersonalizado("Crear evento o competencia", nuevo)
        if (datos.eventos.isEmpty()) Text("No hay eventos registrados.")
        datos.eventos.forEach { e ->
            OutlinedCard(onClick = { detalle(e.id) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(e.nombre, style = MaterialTheme.typography.titleMedium)
                    Text("${Fechas.etiqueta(e.fecha)} · ${e.horaInicio}:00 a ${e.horaFin}:00")
                    EtiquetaEstado(if (!e.activo) "Cancelada" else if (Fechas.futuro(e.fecha, e.horaInicio)) "Inscripciones abiertas" else "Inscripciones cerradas")
                    Text("${datos.equipos.count { it.eventoId == e.id }} de ${e.cupoEquipos} equipos inscritos")
                }
            }
        }
    }
}
