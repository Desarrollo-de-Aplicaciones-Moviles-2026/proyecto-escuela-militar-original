package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun DetalleReservaScreen(reserva: ReservaModel?, datos: DatosApp, admin: Boolean, ocupada: Boolean,
                         cancelar: () -> Unit, aprobar: () -> Unit = {}, rechazar: (String) -> Unit = {}, modificar: () -> Unit = {},
                         motivo: String = "", cambiarMotivo: (String) -> Unit = {}) {
    var confirmarCancelacion by rememberSaveable { mutableStateOf(false) }
    var mostrarRechazo by rememberSaveable { mutableStateOf(false) }
    if (reserva == null) { Pagina { Text("La reserva no está disponible.") }; return }
    val cancha = datos.canchas.firstOrNull { it.id == reserva.canchaId }
    val futuro = Fechas.futuro(reserva.fecha, reserva.horaInicio)
    Pagina {
        Text(cancha?.nombre ?: "Instalación archivada", style = MaterialTheme.typography.headlineSmall)
        EtiquetaEstado(reserva.estado.etiqueta)
        Text("${Fechas.etiqueta(reserva.fecha)} · ${Fechas.horario(reserva.horaInicio)}")
        Text("Participantes ${reserva.participantes}")
        if (admin) Text("Titular ${datos.usuarios.firstOrNull { it.id == reserva.usuarioId }?.nombre.orEmpty()}")
        if (reserva.motivo.isNotBlank()) Text("Motivo ${reserva.motivo}")
        if (reserva.respuesta.isNotBlank()) Text("Respuesta de administración: ${reserva.respuesta}")
        if (admin && reserva.estado == EstadoReserva.PENDIENTE) {
            BotonPersonalizado("Aprobar solicitud", aprobar, habilitado = futuro && !ocupada)
            OutlinedButton(onClick = { mostrarRechazo = true }, enabled = !ocupada, modifier = Modifier.fillMaxWidth()) { Text("Rechazar solicitud") }
        }
        if (futuro && reserva.ocupaHorario) {
            if (admin) OutlinedButton(onClick = modificar, enabled = !ocupada, modifier = Modifier.fillMaxWidth()) { Text("Modificar fecha y hora") }
            OutlinedButton(onClick = { confirmarCancelacion = true }, enabled = !ocupada, modifier = Modifier.fillMaxWidth()) { Text("Cancelar reserva") }
            if (reserva.estado == EstadoReserva.CONFIRMADA) BotonCalendario(reserva, cancha?.nombre.orEmpty())
        }
    }
    if (confirmarCancelacion) ConfirmarDialogo("Cancelar reserva", "Se liberará el bloque y se revisará la lista de espera.", cancelar, { confirmarCancelacion = false })
    if (mostrarRechazo) AlertDialog(onDismissRequest = { mostrarRechazo = false }, title = { Text("Rechazar solicitud") },
        text = { CampoTexto(motivo, cambiarMotivo, "Motivo obligatorio", variasLineas = true) },
        confirmButton = { TextButton(enabled = motivo.isNotBlank(), onClick = { rechazar(motivo); mostrarRechazo = false; cambiarMotivo("") }) { Text("Rechazar") } },
        dismissButton = { TextButton(onClick = { mostrarRechazo = false }) { Text("Volver") } })
}
