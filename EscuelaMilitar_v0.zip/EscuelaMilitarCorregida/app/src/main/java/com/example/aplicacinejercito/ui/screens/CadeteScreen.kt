package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*
import java.time.Instant

@Composable
fun CadeteScreen(estado: AppUiState, nuevaReserva: () -> Unit, verReserva: (String) -> Unit, competencias: () -> Unit, misReservas: () -> Unit) {
    val usuario = estado.usuario ?: return
    val politica = estado.datos.politicas.firstOrNull { it.grado == usuario.grado } ?: return
    val usados = ReglasReserva.tokensUsados(estado.datos.reservas, usuario.id, Fechas.hoy())
    val disponibles = (politica.tokensSemana - usados).coerceAtLeast(0)
    val proxima = estado.datos.reservas.firstOrNull { it.usuarioId == usuario.id && it.ocupaHorario && Fechas.futuro(it.fecha, it.horaInicio) }
    Pagina {
        Text("Hola, ${usuario.nombre.substringBefore(' ')}", style = MaterialTheme.typography.headlineMedium)
        Text("${usuario.grado.etiqueta} · Compañía ${usuario.compania}")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Tokens semanales", style = MaterialTheme.typography.titleMedium)
                Text("Tienes $disponibles de ${politica.tokensSemana} disponibles", style = MaterialTheme.typography.titleLarge)
                LinearProgressIndicator(progress = { disponibles.toFloat() / politica.tokensSemana.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
                Text("Cada solicitud consume 1 token. El cupo se renueva los lunes; se libera al cancelar o rechazar la solicitud.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Button(onClick = nuevaReserva, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)) { Text("Nueva reserva") }
        TituloSeccion("Próxima reserva")
        if (proxima == null) Text("No tienes reservas próximas.") else TarjetaReserva(proxima, estado.datos, { verReserva(proxima.id) })
        OutlinedButton(onClick = misReservas, modifier = Modifier.fillMaxWidth()) { Text("Ver todas mis reservas") }
        TituloSeccion("Eventos y competencias")
        estado.datos.eventos.filter { it.activo && Fechas.futuro(it.fecha, it.horaInicio) }.take(2).forEach {
            OutlinedCard(onClick = competencias, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(it.nombre, style = MaterialTheme.typography.titleMedium)
                    Text("${Fechas.etiqueta(it.fecha)} · ${it.horaInicio}:00")
                }
            }
        }
        TextButton(onClick = competencias) { Text("Ver competencias") }
    }
}
