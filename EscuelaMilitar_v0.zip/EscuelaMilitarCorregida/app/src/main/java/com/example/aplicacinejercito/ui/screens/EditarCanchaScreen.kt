package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.example.aplicacinejercito.data.DatosDemostracion
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun EditarCanchaScreen(f: CanchaFormulario, accion: AccionUiState,
                      cambiar: ((CanchaFormulario) -> CanchaFormulario) -> Unit, guardar: () -> Unit) {
    Pagina {
        Text(if (f.id.isBlank()) "Nueva instalación" else "Editar instalación", style = MaterialTheme.typography.headlineSmall)
        CampoTexto(f.nombre, { valor -> cambiar { it.copy(nombre = valor) } }, "Nombre", f.errores.nombre, habilitado = !accion.cargando)
        Selector("Tipo", f.tipo, (DatosDemostracion.tipos + f.tipo).distinct().sorted(), { valor -> cambiar { it.copy(tipo = valor) } }, !accion.cargando)
        CampoTexto(f.capacidad, { valor -> cambiar { it.copy(capacidad = valor) } }, "Capacidad máxima", f.errores.capacidad, KeyboardType.Number, habilitado = !accion.cargando)
        Selector("Estado", f.estado.etiqueta, EstadoCancha.entries.map { it.etiqueta }, { valor -> cambiar { it.copy(estado = EstadoCancha.entries.first { e -> e.etiqueta == valor }) } }, !accion.cargando)
        CampoTexto(f.apertura, { valor -> cambiar { it.copy(apertura = valor) } }, "Hora de apertura de 0 a 23", teclado = KeyboardType.Number, habilitado = !accion.cargando)
        CampoTexto(f.cierre, { valor -> cambiar { it.copy(cierre = valor) } }, "Hora de cierre de 1 a 24", f.errores.horario, KeyboardType.Number, habilitado = !accion.cargando)
        CampoTexto(f.observaciones, { valor -> cambiar { it.copy(observaciones = valor) } }, "Observaciones", variasLineas = true, habilitado = !accion.cargando)
        Text("Los horarios usan horas enteras. Cada reserva ocupa una hora. Los cambios no pueden dejar reservas o eventos futuros fuera del aforo u horario permitidos.", style = MaterialTheme.typography.bodySmall)
        MensajeError(accion.error)
        BotonPersonalizado("Guardar instalación", guardar, cargando = accion.cargando)
    }
}
