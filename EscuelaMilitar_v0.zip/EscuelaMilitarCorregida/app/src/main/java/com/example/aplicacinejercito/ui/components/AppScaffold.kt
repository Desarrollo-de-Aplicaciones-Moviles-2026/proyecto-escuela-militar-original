package com.example.aplicacinejercito.ui.components

import androidx.compose.foundation.layout.*
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.aplicacinejercito.model.Rol
import com.example.aplicacinejercito.model.UsuarioModel
import com.example.aplicacinejercito.navigation.Rutas

private data class Destino(val ruta: String, val titulo: String, val icono: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(nav: NavHostController, usuario: UsuarioModel, usarRail: Boolean, cargando: Boolean,
                snackbar: SnackbarHostState, contenido: @Composable () -> Unit) {
    BackHandler(enabled = cargando) { /* La operación local termina antes de cambiar de pantalla. */ }
    val destinos = if (usuario.rol == Rol.ADMIN) listOf(
        Destino(Rutas.INICIO, "Inicio", Icons.Default.Home), Destino(Rutas.CALENDARIO, "Calendario", Icons.Default.DateRange),
        Destino(Rutas.EVENTOS, "Eventos", Icons.Default.Star), Destino(Rutas.INSTALACIONES, "Instalaciones", Icons.Default.Place),
        Destino(Rutas.CONFIGURACION, "Configuración", Icons.Default.Settings)
    ) else listOf(
        Destino(Rutas.INICIO, "Inicio", Icons.Default.Home), Destino(Rutas.RESERVAS, "Mis reservas", Icons.Default.DateRange),
        Destino(Rutas.EVENTOS, "Competencias", Icons.Default.Star), Destino(Rutas.CALENDARIO, "Calendario", Icons.Default.CalendarMonth),
        Destino(Rutas.PERFIL, "Perfil", Icons.Default.Person)
    )
    val entrada by nav.currentBackStackEntryAsState()
    val actual = entrada?.destination?.route ?: Rutas.INICIO
    fun ir(destino: String) { nav.navigate(destino) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    } }
    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text(destinos.firstOrNull { it.ruta == actual }?.titulo ?: "Gestión Deportiva") },
                    navigationIcon = { if (destinos.none { it.ruta == actual }) IconButton(onClick = { nav.popBackStack() }, enabled = !cargando) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver") } },
                    actions = { IconButton(onClick = { nav.navigate(Rutas.AVISOS) { launchSingleTop = true } }, enabled = !cargando) { Icon(Icons.Default.Notifications, "Ver avisos") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary, actionIconContentColor = MaterialTheme.colorScheme.onPrimary))
                if (cargando) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        bottomBar = { if (!usarRail) NavigationBar {
            destinos.forEach { d -> NavigationBarItem(selected = actual == d.ruta, onClick = { ir(d.ruta) }, enabled = !cargando, icon = { Icon(d.icono, null) }, label = { Text(d.titulo) }) }
        } },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Row(Modifier.fillMaxSize().padding(padding)) {
            if (usarRail) NavigationRail {
                destinos.forEach { d -> NavigationRailItem(selected = actual == d.ruta, onClick = { ir(d.ruta) }, enabled = !cargando, icon = { Icon(d.icono, null) }, label = { Text(d.titulo) }) }
            }
            Box(Modifier.weight(1f).fillMaxHeight().imePadding()) { contenido() }
        }
    }
}
