package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun ReportesScreen(datos: DatosApp) {
    Pagina {
        Text("Reportes", style = MaterialTheme.typography.headlineSmall)
        Text("Datos registrados en este dispositivo")
        EstadoReserva.entries.forEach { estado -> Text("${estado.etiqueta}: ${datos.reservas.count { it.estado == estado }}") }
        Text("Instalaciones activas: ${datos.canchas.count { it.activa }}")
        Text("Usuarios activos: ${datos.usuarios.count { it.activo && it.rol == Rol.USUARIO }}")
        Text("Equipos inscritos: ${datos.equipos.size}")
        TituloSeccion("Reservas por instalación")
        datos.canchas.forEach { c -> Text("${c.nombre}: ${datos.reservas.count { it.canchaId == c.id }}") }
        BotonExportar(datos)
    }
}
