package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun NuevaReservaScreen(f: ReservaFormulario, datos: DatosApp, politica: PoliticaModel,
                       cambiar: ((ReservaFormulario) -> ReservaFormulario) -> Unit, buscar: () -> Unit) {
    Pagina {
        Text("Paso 1 de 3", style = MaterialTheme.typography.labelLarge)
        TituloSeccion("Busca una instalación")
        Selector("Tipo de instalación", f.tipo, listOf("Todos") + datos.canchas.filter { it.activa }.map { it.tipo }.distinct().sorted(), { valor -> cambiar { it.copy(tipo = valor) } })
        CampoFecha(f.fecha, { valor -> cambiar { it.copy(fecha = valor) } }, f.errores.fecha)
        Selector("Bloque de una hora", Fechas.horario(f.horaInicio), (0..23).map(Fechas::horario), { valor -> cambiar { it.copy(horaInicio = valor.substringBefore(':').toInt()) } })
        MensajeError(f.errores.hora)
        CampoTexto(f.participantes, { valor -> cambiar { it.copy(participantes = valor) } }, "Cantidad de participantes", f.errores.participantes, KeyboardType.Number)
        Text("Tu grado permite reservar hasta ${politica.anticipacionDias} días antes y solicitar ${politica.tokensSemana} bloques por semana.")
        BotonPersonalizado("Ver instalaciones", buscar)
    }
}
