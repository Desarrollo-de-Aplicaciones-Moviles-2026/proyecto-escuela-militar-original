package com.example.aplicacinejercito.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.aplicacinejercito.model.PreferenciasModel
import java.io.IOException
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.preferenciasDataStore by preferencesDataStore(name = "preferencias")

class PreferenciasRepository(context: Context) {
    private val store = context.applicationContext.preferenciasDataStore
    private val tema = booleanPreferencesKey("tema_oscuro")
    private val avisos = booleanPreferencesKey("mostrar_avisos")
    val preferencias = store.data.catch { error ->
        if (error is IOException) emit(emptyPreferences()) else throw error
    }.map { prefs ->
        PreferenciasModel(
            temaOscuro = prefs[tema] ?: false,
            mostrarAvisos = prefs[avisos] ?: true,
            fotos = prefs.asMap().entries.filter { it.key.name.startsWith("foto_") }
                .associate { it.key.name.removePrefix("foto_") to it.value.toString() }
        )
    }
    suspend fun cambiarTema(oscuro: Boolean) { store.edit { it[tema] = oscuro } }
    suspend fun cambiarAvisos(activos: Boolean) { store.edit { it[avisos] = activos } }
    suspend fun guardarFoto(usuarioId: String, uri: String) {
        store.edit { it[stringPreferencesKey("foto_$usuarioId")] = uri }
    }
}
