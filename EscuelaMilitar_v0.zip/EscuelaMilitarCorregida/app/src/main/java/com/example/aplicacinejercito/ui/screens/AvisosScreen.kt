package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun AvisosScreen(estado: AppUiState) {
    val avisos = estado.datos.avisos.filter { it.usuarioId == estado.usuario?.id }
    Pagina {
        Text("Avisos", style = MaterialTheme.typography.headlineSmall)
        if (!estado.preferencias.mostrarAvisos) Text("Los avisos están ocultos. Puedes activarlos desde tu perfil.")
        else {
            if (avisos.isEmpty()) Text("Aún no hay avisos para tu cuenta.")
            avisos.forEach { aviso ->
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(aviso.titulo, style = MaterialTheme.typography.titleMedium)
                        Text(aviso.detalle)
                    }
                }
            }
        }
    }
}
