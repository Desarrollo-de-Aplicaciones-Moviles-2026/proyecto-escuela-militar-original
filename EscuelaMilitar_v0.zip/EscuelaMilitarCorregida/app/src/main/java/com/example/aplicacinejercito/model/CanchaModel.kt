package com.example.aplicacinejercito.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class EstadoCancha(val etiqueta: String) {
    HABILITADA("Disponible"), MANTENIMIENTO("Mantenimiento"), NO_DISPONIBLE("No disponible")
}

@Entity(tableName = "canchas")
data class CanchaModel(
    @PrimaryKey val id: String,
    val nombre: String,
    val tipo: String,
    val capacidad: Int,
    val estado: EstadoCancha = EstadoCancha.HABILITADA,
    val horaApertura: Int = 8,
    val horaCierre: Int = 20,
    val observaciones: String = "",
    val activa: Boolean = true
)
