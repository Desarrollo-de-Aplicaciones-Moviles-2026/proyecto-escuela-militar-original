package com.example.aplicacinejercito.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.example.aplicacinejercito.model.*
import com.example.aplicacinejercito.ui.components.*

@Composable
fun ConfirmarReservaScreen(f: ReservaFormulario, cancha: CanchaModel?, politica: PoliticaModel, accion: AccionUiState,
                          cambiar: ((ReservaFormulario) -> ReservaFormulario) -> Unit, confirmar: () -> Unit) {
    Pagina {
        Text("Paso 3 de 3", style = MaterialTheme.typography.labelLarge)
        Text(cancha?.nombre ?: "Selecciona una instalación", style = MaterialTheme.typography.headlineSmall)
        Text("${Fechas.etiqueta(f.fecha)} · ${Fechas.horario(f.horaInicio)}\n${f.participantes} participantes")
        Text(if (politica.requiereAprobacion) "Se enviará una solicitud pendiente de aprobación." else "La reserva se confirmará al guardar.")
        Text("La solicitud consume 1 token de esta semana y ocupa el bloque mientras se procesa.")
        CampoTexto(f.motivo, { valor -> cambiar { it.copy(motivo = valor) } }, "Motivo u observaciones opcionales", variasLineas = true, habilitado = !accion.cargando)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = f.aceptaNormas, onCheckedChange = { valor -> cambiar { it.copy(aceptaNormas = valor) } }, enabled = !accion.cargando)
            Text("Acepto las normas de uso y devolveré la instalación en buenas condiciones.", Modifier.weight(1f))
        }
        MensajeError(f.errores.normas)
        MensajeError(accion.error)
        BotonPersonalizado("Confirmar solicitud", confirmar, cargando = accion.cargando, habilitado = cancha != null)
    }
}
