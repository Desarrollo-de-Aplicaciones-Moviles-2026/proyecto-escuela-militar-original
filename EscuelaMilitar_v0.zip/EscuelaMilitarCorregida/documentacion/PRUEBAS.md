# Guía de pruebas de Gestión Deportiva

Estas pruebas permiten revisar los flujos de la versión corregida y relacionarlos con los contenidos de clases. Los casos manuales son una guía de comprobación en teléfono o emulador: no implican que ya se hayan ejecutado en un dispositivo.

## Pruebas automáticas incluidas

`ValidadoresTest.kt` comprueba correo y contraseña, formato y límites de fecha, inicio del bloque, capacidad, aceptación de normas, horario de apertura, superposición, tokens semanales y bloqueo por eventos. Usa un reloj fijo para evitar que los resultados cambien según el día de ejecución.

`RepositorioInstrumentedTest.kt` usa Room y comprueba dos solicitudes simultáneas, asignación desde la espera, rechazo con devolución de token, autorización de administración y persistencia al cerrar y reabrir una base de datos en disco. Estos casos requieren un emulador o teléfono.

Para pruebas locales y análisis:

```bash
./gradlew assembleDebug testDebugUnitTest lintDebug
```

Para compilar las pruebas de dispositivo sin ejecutarlas:

```bash
./gradlew assembleDebugAndroidTest
```

Para ejecutarlas, conecta un teléfono de prueba o inicia un emulador:

```bash
./gradlew connectedDebugAndroidTest
```

## Casos manuales

Conviene comenzar con una instalación de prueba limpia y usar las cuentas del README. Para probar distintos usuarios y administración, cierra sesión desde Perfil; toda la información se comparte en la base local del mismo dispositivo.

| Caso | Acción | Resultado esperado |
| --- | --- | --- |
| Campos vacíos | Presiona Ingresar sin datos | Errores debajo de correo y contraseña; no navega |
| Dominio falso | Usa `usuario@escuelamilitar.cl.otro` | Error de dominio |
| Normalización | Usa ` M.LEIVA@ESCUELAMILITAR.CL ` y la clave de prueba | Acceso a la cuenta de Martín |
| Cuenta inexistente | Usa `admininventado@escuelamilitar.cl` | No obtiene administración |
| Clave incorrecta | Usa una cuenta válida y `Otra123` | No permite entrar |
| Cuenta archivada | Usa `i.fuentes@escuelamilitar.cl` | Rechaza el acceso |
| Pestañas | Recorre los destinos inferiores | Cambia realmente la pantalla |
| Perfil | Abre Perfil | Muestra los datos y preferencias; no cierra sesión |
| Reserva válida | Solicita mañana, tenis a las 11:00 y 2 participantes | Pendiente, consume un token y aparece en Mis reservas |
| Normas | Intenta confirmar sin aceptar las normas | Error visible y no crea una reserva |
| Fecha inválida | Ingresa `2026-02-30` | Error por fecha inválida |
| Plazo por grado | Como cadete intenta un día a más de 3 días de hoy | Error de anticipación |
| Capacidad | Solicita tenis para 9 personas | Rechaza por capacidad máxima de 8 |
| Instalación cerrada | Busca piscina o un bloque fuera de apertura | No ofrece una reserva válida |
| Colisión | Con otra cuenta busca la misma cancha y bloque reservado | Muestra Ocupada; no crea otra reserva en el bloque |
| Doble ocupación personal | Intenta solicitar otra instalación a la misma hora | Rechaza por reserva simultánea del titular |
| Token agotado | Como cadete con una solicitud activa intenta otro bloque | Rechaza por falta de tokens |
| Aprobación | Entra como admin y aprueba la solicitud | Confirmada y aviso al titular |
| Rechazo | Rechaza una solicitud con motivo | Rechazada, motivo visible y token liberado |
| Cancelación | Cancela una reserva futura activa | Pide confirmar; cancela y libera el bloque |
| Espera | Una cuenta se une a un bloque ocupado y el titular cancela | Se asigna a la primera cuenta elegible y se generan avisos |
| Competencia | Crea un evento en una cancha libre | El calendario muestra el evento y sus bloques quedan impedidos para reservas personales |
| Evento en conflicto | Crea un evento sobre una reserva activa | Rechaza y pide resolver primero el conflicto |
| Equipo | Crea equipo con miembros de tu compañía y el mínimo requerido | Se guarda, aparece en el evento y cambia el cupo disponible |
| Integrante duplicado | Intenta usar un miembro de otro equipo del mismo evento | No permite duplicar la inscripción |
| Instalación | Como admin crea y edita una instalación | Aparece en el listado con los cambios |
| Aforo en conflicto | Reduce la capacidad por debajo de una reserva futura | Rechaza el cambio |
| Archivo de instalación | Intenta archivar una cancha con reservas futuras | Exige cancelarlas o reprogramarlas primero |
| Archivo de cuenta | Archiva una cuenta con reservas futuras | Cancela esas reservas y conserva el historial |
| Políticas | Cambia tokens o anticipación y reinicia la app | Se conservan los valores |
| Tema | Activa el tema oscuro y reinicia | El tema oscuro permanece |
| Rotación | Escribe una reserva y gira el dispositivo | Conserva el borrador y adapta la navegación |
| Ventana amplia | Usa un emulador tablet o una ventana de al menos 600 dp | Muestra navegación lateral |
| Foto | Selecciona una foto, cierra y abre la app | Conserva el acceso cuando el proveedor permite persistirlo |
| Selector cancelado | Abre el selector de foto o de exportación y vuelve sin elegir | Continúa sin error ni confirmación falsa |
| Calendario externo | En reserva confirmada usa Agregar al calendario | Abre el calendario; si no hay app disponible informa el problema |
| Exportación | Como admin ve a Reportes y exporta | Archivo CSV con registros reales, encabezados y texto UTF-8 |
| Cierre de sesión | Sal de una cuenta y presiona Atrás | No vuelve a la pantalla de la cuenta anterior |
| Cierre de proceso | Android termina el proceso y se vuelve a abrir | Pide ingresar; conserva registros y preferencias |

## Cómo interpretar el alcance de las pruebas

Compilar verifica sintaxis, dependencias, recursos, código generado por Room y empaquetado. Las pruebas locales verifican reglas concretas. Lint analiza problemas estáticos. Ninguna de esas comprobaciones sustituye revisar la navegación, los permisos y la presentación en un dispositivo.

Las pruebas de Room y las pruebas manuales requieren un dispositivo de prueba. El archivo [VERIFICACION.md](VERIFICACION.md) registra cuáles comprobaciones se ejecutaron al preparar esta entrega.
