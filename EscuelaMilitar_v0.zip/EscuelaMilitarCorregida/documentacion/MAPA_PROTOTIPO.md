# Correspondencia entre el prototipo HTML y la app Android

El HTML se usó como guía de navegación, datos y diseño. La app agrupa algunas vistas y sustituye las pantallas exclusivas de confirmación por un detalle actualizado y un mensaje de resultado. La tabla distingue esas agrupaciones; no se trata de una reproducción visual exacta de cada estado del HTML.

| Pantalla o grupo del HTML | Lugar en la app corregida | Adaptación |
| --- | --- | --- |
| Login | `LoginScreen.kt` | Acceso local con cuentas explícitas y errores por campo |
| Inicio del usuario | `CadeteScreen.kt` | También sirve a tenientes y cabos; usa el grado de la cuenta |
| Nueva reserva | `NuevaReservaScreen` | Tipo, fecha, hora y participantes |
| Resultados | `ResultadosScreen` | Estado del bloque calculado con datos reales |
| Detalle de instalación y espera | `InstalacionUsuarioScreen` | Espera persistente por bloque |
| Solicitar reserva | `ConfirmarReservaScreen` | Normas, motivo, consumo y aprobación |
| Solicitud enviada | Detalle de reserva y aviso de resultado | Sin una pantalla adicional vacía de navegación |
| Horario recién reservado | Mensaje de error de la operación | Comprobación real al guardar; no se provoca artificialmente al elegir Estadio |
| Mis reservas e historial | `MisReservasScreen` | Dos destinos que reutilizan la misma vista con filtros |
| Detalle y cancelación de reserva | `DetalleReservaScreen` | Confirmación antes de cancelar |
| Calendario del usuario y general | `CalendarioScreen` | Ocupación real; detalles personales reservados al titular o administración |
| Competencias | `EventosScreen` y `DetalleEventoScreen` | Cupos derivados de equipos guardados |
| Crear equipo y equipo creado | `CrearEquipoScreen` y detalle del evento | Validación y confirmación con el equipo persistido |
| Perfil, configuración personal y ayuda | `PerfilScreen`, `AyudaScreen` | Foto, tema, avisos y salida explícita |
| Notificaciones de usuario y admin | `AvisosScreen` | Avisos internos persistentes; sin push ni recordatorios programados |
| Inicio de administración | `AdminScreen.kt` | Métricas del momento y solicitudes reales |
| Solicitudes y rechazo | `SolicitudesScreen` y detalle | Procesamiento individual, filtro por estado y grado; motivo de rechazo |
| Creación de evento en dos pasos | `CrearEventoScreen` | Un formulario con datos e instalaciones seleccionadas |
| Instalaciones y ficha | `InstalacionesScreen`, `FichaCanchaScreen` | Búsqueda, archivo y restauración |
| Nueva instalación y edición | `EditarCanchaScreen` | Un solo formulario controlado por AdminViewModel |
| Horarios y disponibilidad | Edición y ficha de instalación | Horario diario continuo en horas enteras; sin selección independiente de días de la semana |
| Historial de uso | Ficha de instalación y reportes | Registros reales; sin datos aleatorios de uso |
| Modificar reserva | `ReprogramarReservaScreen` | Se conserva la semana del token y se revisa la nueva disponibilidad |
| Configuración y perfil de admin | `ConfiguracionScreen`, `PerfilScreen` | Destinos diferenciados; Configuración ya no cierra sesión |
| Políticas | `PoliticasScreen` | Tokens, anticipación y aprobación por grado |
| Usuarios y perfil de usuario | `UsuariosScreen`, `DetalleUsuarioScreen` | Archivo y restauración conservando historial; confirmación de la acción |
| Reportes | `ReportesScreen` | Conteos locales y exportación CSV; sin porcentajes ficticios ni gráficos de utilización inventados |
| Calendario institucional | `CalendarioScreen` en modo institucional | Eventos efectivamente registrados; no se cargan feriados legales como datos supuestos |

Las simplificaciones de esta versión son explícitas: aprobación individual, horario diario continuo y preferencias generales de avisos. Si una pauta exige aprobación masiva, reglas por día de la semana, motivos de baja estructurados o categorías de avisos con recordatorios, esos requisitos no se pueden dar por cumplidos con esta implementación. No se identificaron como exigencias específicas en el material de clases adjunto.
