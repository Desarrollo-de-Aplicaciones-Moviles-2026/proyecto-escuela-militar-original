# Revisión y corrección del proyecto de Gestión Deportiva

El proyecto de tu compañero sigue **parte de la estructura propuesta en clases**, pero todavía no implementaba MVVM de manera funcional. Tenía una Activity, Compose, Material 3 y un NavHost; sin embargo, los archivos de modelos, ViewModels y componentes compartidos estaban vacíos. La mayor parte de lo visible eran maquetas con datos escritos directamente en las pantallas.

La corrección convierte esa base en una aplicación local de demostración con responsabilidades separadas, formularios observables y datos persistentes. Mantiene la idea de Gestión Deportiva de la Escuela Militar y las reglas principales del prototipo. Esta revisión se basa en los tres archivos adjuntos. El DOCX contiene 43 imágenes; las referencias siguientes corresponden a su orden dentro del documento, no a números de página ni a una pauta de evaluación.

## Qué estaba bien encaminado

Se conservaron Kotlin, Jetpack Compose, Material 3, el identificador de la aplicación y la Activity como punto de entrada. También se conservó la separación conceptual entre usuario y administración, la navegación con Navigation Compose, los colores institucionales y las instalaciones y compañías del prototipo.

Las carpetas `model/`, `viewmodel/` y `navigation/` ya expresaban la intención correcta. El problema era que varios archivos contenían únicamente la declaración `package`. Tener la carpeta o un archivo llamado ViewModel no aplica el patrón si la pantalla sigue realizando las validaciones y administrando los datos por sí sola.

## Comparación con las clases

| Contenido del material | Evidencia en el original | Corrección |
| --- | --- | --- |
| MVVM y separación de responsabilidades, imágenes 2 y 4 | `CanchaModel`, `ReservaModel` y los tres ViewModels estaban vacíos | Modelos reales, ViewModels con estado y repositorio con operaciones transaccionales |
| Pantallas y componentes en `ui/`, imágenes 4, 11 y 23 | Pantallas y componentes estaban dentro de `ui/theme/` | Una pantalla por archivo en `ui/screens/` y componentes en `ui/components/`; `ui/theme/` contiene el tema |
| Data class para el formulario y otra clase para errores, imágenes 22 y 23 | Correo, contraseña y errores eran variables independientes dentro de LoginScreen | `LoginUiState`, `LoginErrores` y modelos equivalentes para reservas, instalaciones, eventos y equipos |
| Validaciones desde el ViewModel, imágenes 15, 25, 26, 28 y 29 | Las reglas de acceso estaban en el `onClick` del botón de LoginScreen | ViewModels actualizan los modelos y llaman a validadores comprobables; el repositorio vuelve a comprobar las reglas al guardar |
| MutableStateFlow y StateFlow observable, imágenes 23, 27, 28 y 30 | No existía StateFlow en los ViewModels | StateFlow de solo lectura para las pantallas y `collectAsStateWithLifecycle()` en la integración Compose |
| MaterialTheme, colores, tipografía y formas, imágenes 6 a 8 | Había un tema autogenerado morado y colores institucionales repetidos localmente | Paleta institucional clara y oscura, formas y tipografía centralizadas |
| Window Size Classes, imágenes 10 y 11 | No se usaban; los diseños estaban pensados para un único tamaño | `calculateWindowSizeClass()` en la Activity; navegación inferior en Compact, lateral en Medium y Expanded; login dividido en Expanded |
| Estado y persistencia, imágenes 33 a 35 | Estado local con `remember` y ausencia de almacenamiento | Borradores en ViewModels, estado visual sencillo con `rememberSaveable`, preferencias con DataStore y registros con Room |
| Animaciones y carga, imágenes 36 y 37 | No había estados de trabajo para operaciones de datos | Botones deshabilitados durante el envío, indicadores de progreso, `AnimatedVisibility` y `animateColorAsState` |
| Recursos nativos y Activity Result API, imágenes 39 y 40 | No había integración nativa de datos | Selección de foto con OpenDocument, exportación CSV con CreateDocument y apertura del calendario mediante Intent |
| SQLite, CRUD y Room, imágenes 42 y 43 | Sin base de datos | Entidades, DAO, consultas observables, inserciones, actualizaciones, eliminación de inscripciones y lista de espera |

La imagen 8 permite estilos locales: escribir un color dentro de un Composable no es, por sí solo, un incumplimiento. Centralicé los valores compartidos para hacer consistente el diseño. Tampoco es incorrecto usar `remember` para abrir un menú o controlar un diálogo; la diferencia es que los datos y las validaciones del negocio ya no dependen de ese estado local.

## Cambios funcionales

**Inicio de sesión y sesión.** El original avanzaba después de comprobar el formato del correo y la contraseña. El rol se deducía del prefijo `admin`. Ahora se busca una cuenta precargada, se compara la clave de demostración y se obtiene el rol de `UsuarioModel`. Los correos se normalizan eliminando espacios externos y usando minúsculas. Las cuentas archivadas no ingresan. La contraseña se limpia al completar el acceso. Al salir se descarta el NavHost de esa sesión, por lo que Atrás no abre la cuenta anterior.

Se mantuvo la regla heredada de contraseña del proyecto inicial: primera letra mayúscula, al menos un dígito y máximo ocho caracteres. **Esa regla no aparece como requisito específico en las imágenes adjuntas.** La clave de prueba `Clave123` la cumple. No es una recomendación para diseñar autenticación de producción; si existe una pauta adicional del profesor, esa regla debe ajustarse a ella en `ValidadorLogin`.

**Navegación.** Los botones inferiores del original cambiaban `selectedTab`, pero la pantalla dibujaba el mismo contenido. Perfil y Configuración llamaban a `onLogout()` como acceso directo. Ahora cada opción abre su destino y Cerrar sesión es una acción explícita con confirmación. Nueva reserva, solicitudes, instalaciones, competencias, calendario, perfil y configuración tienen contenido y acciones conectados.

**Reservas y tokens.** Se implementó el recorrido de búsqueda, detalle, aceptación de normas, envío y consulta del estado. Las reservas son bloques exclusivos de una hora; la capacidad indica el tamaño máximo del grupo. Se controlan fecha, anticipación por grado, horario de apertura, aforo, tokens y superposición con reservas o eventos. Una solicitud pendiente ocupa el bloque para evitar que se asigne dos veces. El repositorio vuelve a consultar los datos dentro de una transacción antes de insertar.

Los tokens se calculan a partir de las solicitudes pendientes y confirmadas de la semana de solicitud, desde el lunes en la zona America/Santiago. Cancelar o rechazar deja de contar ese consumo. Cancelar una solicitud de una semana anterior no crea tokens adicionales en la semana actual. Esta definición hace concreta la renovación semanal que el prototipo describía sin una persistencia real.

**Administración.** Se implementaron aprobación y rechazo individual con motivo, cancelación y cambio de fecha y hora de reservas. Las instalaciones se crean, editan, archivan y restauran. Un cambio de aforo, horario o estado no puede invalidar silenciosamente reservas o eventos futuros. Los usuarios se archivan y restauran conservando su historial; al archivarlos se cancelan sus reservas futuras. Las políticas por grado se pueden editar y persistir.

**Lista de espera.** El HTML guardaba la participación en memoria. Ahora existe una fila persistente por usuario y bloque. Al cancelar o rechazar una reserva, el repositorio revisa la lista por orden de llegada y asigna el cupo a la primera cuenta que cumple las reglas. Si una cuenta dejó de cumplirlas, se elimina esa entrada, se genera un aviso y se revisa la siguiente. La asignación consume un token y respeta la aprobación exigida por la política vigente.

**Competencias y equipos.** Los eventos bloquean sus instalaciones durante el intervalo configurado. Se comprueban conflictos al crearlos. Los usuarios forman equipos con integrantes activos de su compañía; el capitán queda incluido, se exige el mínimo y una persona no puede integrar dos equipos del mismo evento. El cupo se obtiene de las inscripciones guardadas. El capitán o la administración puede retirar el equipo antes del inicio.

**Datos coherentes.** Se retiraron fechas fijas como el domingo 27 de septiembre y cifras de ocupación, tokens o solicitudes escritas directamente en las pantallas. El inicio, el calendario, los avisos y los reportes consultan los registros. La carga inicial conserva 15 instalaciones y cinco competencias del prototipo, pero comienza con dos reservas consistentes y sin equipos inventados para llenar contadores. Los eventos de muestra se ubican respecto de la primera instalación y luego conservan sus fechas.

**Persistencia y recursos nativos.** Room guarda las entidades y DataStore guarda tema, visibilidad de avisos y URI de foto por cuenta. La foto se selecciona con Android; los reportes se exportan con el selector de destino del sistema. Una reserva confirmada puede abrir el calendario para su revisión. No se agregaron permisos generales de almacenamiento ni de calendario. Los avisos permanecen dentro de la app.

## Qué se tomó del prototipo y qué se decidió al corregir

| Regla o decisión | Origen |
| --- | --- |
| Teniente 3 tokens y 14 días; cabo 2 y 7; cadete 1 y 3 | Objeto `POL0` del HTML |
| Bloques fijos de una hora y aprobación inicial por grado | HTML, constantes y políticas |
| Nombres de instalaciones, compañías, usuarios principales y competencias | HTML |
| Data class, errores por campo, ViewModel, StateFlow, tema y adaptación | Material de clases |
| Room para datos y DataStore para preferencias | Aplicación de los conceptos de las imágenes 35, 42 y 43 a este proyecto |
| Acceso con cuentas de demostración explícitas | Decisión de implementación; evita deducir privilegios solo del texto del correo |
| Comprobación de colisiones en transacciones y devolución por semana de solicitud | Decisión para concretar las reglas del prototipo de forma consistente |
| Elección de foto, exportación y calendario | Ejemplos de APIs nativas adecuados a la app; el material no exige usar todas las APIs listadas |
| Formularios y pantallas reunidos por función | Decisión para mantener una app comprensible; ver el mapa del prototipo |

## Configuración de compilación

Se fijó un conjunto de versiones documentado y compatible con JDK 17 y SDK 35. Es una decisión de reproducibilidad de esta entrega, no una versión impuesta por los PPT ni una afirmación de que todas las versiones originales fueran inexistentes.

| Elemento | ZIP original | Versión corregida |
| --- | --- | --- |
| Android Gradle Plugin | 9.4.1 | 8.7.3 |
| Gradle | 9.6.0 | 8.9 |
| Kotlin | 2.2.10 | 2.0.21 |
| Compose BOM | 2026.02.01 | 2024.12.01 |
| compileSdk y targetSdk | 37 | 35 |
| minSdk | 24 | 24 |
| Compatibilidad de código Java | 11 | 17 |
| Criterio de JVM del daemon | 25 con descarga automática | JDK 17 configurado en Android Studio |

Se agregaron explícitamente las dependencias de ViewModel, Lifecycle Compose, Room, KSP, DataStore, corrutinas y Window Size Classes. Se retiró la configuración de optimización propia del conjunto original y los archivos locales del IDE. KSP incremental queda desactivado para regenerar de forma consistente los archivos de Room en este proyecto académico. El identificador `com.example.aplicacinejercito` se conservó para evitar un cambio de paquete innecesario.

## Cómo explicarlo al profesor

Puedes seguir un dato de principio a fin: el correo pertenece a `LoginUiState`; `LoginScreen` lo dibuja y llama al evento de cambio; `LoginViewModel` actualiza el StateFlow, valida y pide el acceso al repositorio. En una reserva se repite el recorrido y, al guardar, el repositorio verifica las reglas y usa el DAO de Room dentro de una transacción. El cambio en la base emite un Flow que actualiza las pantallas.

No es necesario presentar repositorios remotos, servicios en la nube o autenticación real para explicar lo implementado. Esta entrega permite mostrar los conceptos presentes en el material con datos locales. Antes de una evaluación, conviene contrastar la [guía de pruebas](PRUEBAS.md) con cualquier pauta adicional que no se haya adjuntado.

## Referencias técnicas complementarias

Se consultó documentación oficial para contrastar las APIs y la configuración, sin sustituir el material de clases:

- [Compatibilidad de Android Gradle Plugin 8.7](https://developer.android.com/build/releases/agp-8-7-0-release-notes)
- [Estado y Jetpack Compose](https://developer.android.com/develop/ui/compose/state)
- [Corrutinas y componentes con ciclo de vida](https://developer.android.com/topic/libraries/architecture/coroutines)
- [Persistencia local con Room](https://developer.android.com/training/data-storage/room)
- [DataStore](https://developer.android.com/topic/libraries/architecture/datastore)
